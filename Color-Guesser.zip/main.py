import tkinter 
import random

#TIME LEFT BOI
timeleft=30

#Variable for score
score=0

colors=["blue","red","green","black","brown","purple","orange","yellow","pink"]

root=tkinter.Tk()
root.configure(bg="teal")

root.title("Type the Color and not the Word project by UNKNOWNCAT")
root.geometry("800x500")
                          
instructions=tkinter.Label(root,text="Type the Color and not the Word.  you have 30 seconds",font=("timesnewroman",10))
instructions.pack()

scorelabel=tkinter.Label(root,text='Press enter to start',font=('jokerman',10))
scorelabel.pack()

#creating a l
timelabel=tkinter.Label(root,text='time left:'+str(timeleft),font=('chiller',10))
timelabel.pack()

#COlornames
collabel=tkinter.Label(root,font=('jokerman',10))
collabel.pack()
##creating a textbox to type the colors
txtbox=tkinter.Entry(root)
txtbox.pack()
# setting the focus on the entry box
txtbox.focus_set()

# creating a countdown timer function
def cd():
  global timeleft
  #if the game is in play
  if timeleft>0:
    timeleft=timeleft-1
  timelabel.configure(text='time left:'+str(timeleft))
  
  #reducing the function again after 1 sec
  timelabel.after(1000,cd)

def nextcolor():
	global score
	global timeleft
	#if the game is in play
	if timeleft >0:
		#making textbox
		txtbox.focus_set()
		# id the color type is = to color text
		if txtbox.get().lower()==colors[1].lower():
			score=score+1
		#clearing the textbox
		txtbox.delete(0,tkinter.END)
		#shuffing the color list
		random.shuffle(colors)
		#Change the color to type by changing the text and the color to a random color value
		collabel.config(fg=str(colors[1]),text=str(colors[0]))
		#updating score
		scorelabel.config(text="score is:"+str(score))
# creating a function that will start the game
def sg(event):
  if timeleft==30:
    cd()
	#running the function to choose the next color
  nextcolor()
 
#running start when enter is pressed
root.bind("<Return>",sg)        
root.mainloop